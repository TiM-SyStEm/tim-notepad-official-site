using System;
using System.IO;
using System.Windows.Forms;

public class Program
{
    public static void Main(string[] args)
    {
        MessageBox.Show("Привет!");
    }  
}