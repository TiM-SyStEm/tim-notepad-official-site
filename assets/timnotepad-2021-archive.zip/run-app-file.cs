using System;
using System.IO;
 
class Program
{
    static void Main(string[] args)
    {
        Console.ReadLine();
    }
}